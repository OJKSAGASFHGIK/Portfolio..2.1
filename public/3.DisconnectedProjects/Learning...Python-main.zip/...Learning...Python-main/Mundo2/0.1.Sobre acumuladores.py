#É comum usar em acumuladores:
#v = 0, v1 += v2, v += 1
#!=, ==