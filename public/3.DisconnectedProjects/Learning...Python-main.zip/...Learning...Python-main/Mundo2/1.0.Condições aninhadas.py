a1 = input('Qual seu nome? ')
if a1 == 'Astolfo':
 print('Gostei desse... vou até parar com os nomes de anime.')
elif a1 == 'Luffy' or a1 == 'Goku' or a1 == 'Ichigo':
 print('Então quer dizer que você é otaku...')
elif a1 == 'Greque':
 print(''' Esse foi meu nome em um jogo antigo...
 Vai ganhar o titulo: "Games para tartarugas."
 Não posso ti dar esse nick(e não jogue MMORPG).''')
elif a1 == 'Frisk' or a1 == 'Chara':
 print(''' Isso aqui deve ter ti lembrado undertale.
 To estudando, e isso foi a melhor ideia que tive para...
 Bem, testar uns comandos aqui no Python.''')
else:
 print('Tomara que você não precise trocar seu nome num cartorio...')