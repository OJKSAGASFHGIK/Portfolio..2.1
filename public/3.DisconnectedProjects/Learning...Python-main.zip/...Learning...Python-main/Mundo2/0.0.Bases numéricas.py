#-Números:
#O termo comum que a gente usa pra definir um número naturalmente, é chamado
# "número decimal", e eles são chamados assim, porque em um número...
# cada casa é baseada numa potência de 10. E levando isso em um ponto mais
# extremo, a ideia da númeração natural ser baseada em potências de 10, é
# porque a gente tem 10 dedos. O que apesar de parecer extremo, também tem
# o seu sentido. Deixando a linha de diálogo um pouco de lado. Vamos a
# exemplos práticos:
# O número 1024, tem:
# 1 milhar, que é = a 10³*1
# 0 centenas, que é = a 10²*0
# 2 dezenas, que é = a 10¹*2
# 4 únidades, que é = 10º*4 (Todo número elevado a 0, é igual a 1)
#Esse é o sistema usado por humanos naturalmente todo dia. Agora quando se
# trata de computadores... é o clássico sistema de 0 e 1, como muitos sabem.
# Agora o que muitos não sabem, é a lógica por trás desses números.
#
#-Números binários: (aprofundar)
#Já os números binários, invés de seus inteiros serem baseados em 10, os
# seus calculos são baseados em multiplicações de potências com 2, e
# divisões sequenciais de 2, com obtenção de restos em 0 e 1.
