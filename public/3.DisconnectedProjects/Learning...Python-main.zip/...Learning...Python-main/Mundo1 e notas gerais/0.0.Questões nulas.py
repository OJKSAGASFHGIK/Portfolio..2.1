#Espaços são automáticamente repetidos fora dos " '' ", na parte
#de comandos.
#===
#Vc pode usar "#" para ignorar e tentar uma nova linha de comando,
#sem apagar a antiga.
#===
#quit() , serve para encerrar linha de comando.