#Celsius para farenheit:
# farenheit = celsius * 1.8 + 32

#v1 = float(input('')) , print(int(v1))

#Hipotenusa: math.hypot(v1,v2)
# (3**2+3**2)/0.5

#from math import sin,cos,tan,radians
# exemplo: v2 = sin(radians(v1))

#from random import randint,choice,shuffle

#from pygame import mixer,init,event
# mixer.init() init() mixer.music.load('.mp3') mixer.music.play() event.wait()

#Milhar:
# v2 = v1 // 1000 % 10

#rfind

#from datetime import date
# date.today().year
#ano bissexto:
# if v1%4==0 and v1%100 != 0 or v1%400 == 0:

