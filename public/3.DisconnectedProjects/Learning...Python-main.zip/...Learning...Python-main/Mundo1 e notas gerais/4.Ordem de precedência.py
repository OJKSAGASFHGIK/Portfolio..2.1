Ordem de precedência:
===
# " () "
# " ** " = Potências
# " * / // % "
# " + - "
===
Notas:
#Na programação em python, o simbolo da "%", nn é porcentagem, e sim,
#na verdade, o resto de uma divisão(literalmente). E "//" é o resultado
#de uma divisão simples. Ou seja: Vc pode receber resultados inteiros
#(dentro de uma divisão).
# " // " = Divisão inteira
# " % " = Resto da divisão