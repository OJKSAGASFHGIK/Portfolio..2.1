a1 = int(input('Quanto tempo tem seu computador? '))
if a1 >= 8:
    print('Carai... ta na hora de trocar.')
else:
    print('Agora preserve mais alguns anos.')
print('Boa sorte com seu guerreiro!')
input('NEXT:===')
#
a2 = input('Qual seu nome? ')
if a2 == 'Marcus Guilherme':
    print('Isso sim, é o nome de uma pessoa gostosa e tesuda!')
else:
    print('Não é um nome tão delicioso... :/')
input('NEXT:===')
#
a3 = input('Você ta com sono? (Sim/Não) ')
if a3 == 'Sim':
    print("""Eu imagino... dormir agora, seria bom né? Relaxa,
     vai la dormir. Depois você ajeita isso aqui.""")
input('NEXT:===')
#
a4 = input('''Seria justo descansar um pouco agora? Me refiro a fazer algo
 prazeroso de verdade um pouco... ? (sim/não) : ''')
print('Pode crer!'if a4=='sim' else'Entendo...')
input('NEXT:===')