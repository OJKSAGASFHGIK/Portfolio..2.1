#\33[m
#style: 0=none, 1=bold, 4=underline, 7=negative
#text: 30=black, 31=red, 32=green, 33=yellow, 34=blue, 35=magenta, 36= cyan,
# 37=grey, 97=white
#background: 40=black, 41=red, 42=green, 43=yellow, 44=blue, 45=magenta,
# 46=cyan, 47=grey, 107=white

color = {'red':'\33[31m',
 'green':'\33[32m',
 'purple':'\33[35m',
 'grey.s':'\33[7:37:107m',
 'clean':'\33[m'}
#
print(f'Condições \33[4;32mfinanceiras\33[m e \33[4;31mviolência\33[m né?')
input('-> '*2)
#
pedra = '\33[1;37mPEDRA\33[m'
pena =  '\33[1;97mPENA\33[m'
print(f'''Se lembre das bases brutas da vida, {pedra} e {pena}. Olhe para
 suas mãos... pense na sua vida em 1¹ pessoa, e lembre que ninguém merece
 mais a sua palavra do que você mesmo.''')
input('-> '*2)
print('''Lembre do aspecto podre da vida, que você não escolhe viver,
 e que grande parte da consequência dos casos de violência mental e fisica
 se dá por origem do sexo e reprodução indiscriminada.''')
input('-> '*2)
print('''A reprodução sem responsabilidade, o sexo por puro prazer, sem
 preservativo. A fantasia de que ter um filho vai ser fácil...
 quando na verdade, um simples gozar, define toda responsabilidade da
 humanidade.''')
input('-> '*2)
print('''Você não tem que se sentir mal por não estar produzindo capital
 ainda, parte da sua vida é consequência do mundo, e você não é um lixo. 
 Se você sempre tenta seguir seu sonho e propósito com pé no chão...
 as pessoa não merecem sua palavra. Respire, lembre suas bases, olhe pra si,
 se frustre para amadurecer novamente.''')
input('-> '*2)
print(f'''Só você tem o direito de julgar seu amadurecimento. Mantenha sua 
 essência, as coisas que você acreditou dignas de verdade no passado, e
 as coisas que não faziam tanto sentido e só ti fizeram mal. Viva por quem
 você foi e quem você quer ser. Tenha {pedra} e {pena}.''')
#
input('-> '*2)
print(f'{color["grey.s"]}Respira...{color["clean"]} vai ficar tudo ok... :)')