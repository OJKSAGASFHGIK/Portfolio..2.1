#https://www.youtube.com/watch?v=s3r8_Aug4y8
#Pontos importantes:
#17:18 - Módulos úteis , 21:44 - from module import function (function = def),
#23:14 - __init__.py
from beautifulTitle import beautifulTitle, next