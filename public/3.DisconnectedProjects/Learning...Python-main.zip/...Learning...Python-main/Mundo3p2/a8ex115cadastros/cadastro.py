from Mundo3p2.a8ex115cadastros.cadastroFinal import cadastros

cadastros('First room')